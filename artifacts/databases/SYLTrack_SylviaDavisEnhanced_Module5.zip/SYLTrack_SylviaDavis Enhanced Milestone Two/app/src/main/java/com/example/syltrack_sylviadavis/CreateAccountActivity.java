package com.example.syltrack_sylviadavis;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.syltrack_sylviadavis.data.AppDatabaseHelper;

/**
 * CreateAccountActivity
 * - Lets first-time users create a username/password
 * - Saves new credentials to SQLite
 * - Adds stronger validation (security mindset)
 */
public class CreateAccountActivity extends AppCompatActivity {

    private EditText editNewUsername, editNewPassword;
    private Button buttonSaveAccount;
    private AppDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        dbHelper = new AppDatabaseHelper(this);

        editNewUsername = findViewById(R.id.editNewUsername);
        editNewPassword = findViewById(R.id.editNewPassword);
        buttonSaveAccount = findViewById(R.id.buttonSaveAccount);

        buttonSaveAccount.setOnClickListener(v -> createAccount());
    }

    private void createAccount() {
        String username = editNewUsername.getText().toString().trim();
        String password = editNewPassword.getText().toString().trim();

        // ✅ Validation: empty checks
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter a username and password.", Toast.LENGTH_SHORT).show();
            return;
        }

        // ✅ Validation: stronger guardrails
        if (username.length() < 3) {
            Toast.makeText(this, "Username must be at least 3 characters.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (password.length() < 4) {
            Toast.makeText(this, "Password must be at least 4 characters.", Toast.LENGTH_SHORT).show();
            return;
        }

        //  keep usernames simple
        if (username.contains(" ")) {
            Toast.makeText(this, "Username cannot contain spaces.", Toast.LENGTH_SHORT).show();
            return;
        }

        // ✅ Prevent duplicates (database integrity)
        if (dbHelper.userExists(username)) {
            Toast.makeText(this, "Username already exists. Choose another.", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean saved = dbHelper.addUser(username, password);
        if (saved) {
            Toast.makeText(this, "Account created! Please log in.", Toast.LENGTH_SHORT).show();
            finish(); // return to login screen
        } else {
            Toast.makeText(this, "Error saving account. Try again.", Toast.LENGTH_SHORT).show();
        }
    }
}

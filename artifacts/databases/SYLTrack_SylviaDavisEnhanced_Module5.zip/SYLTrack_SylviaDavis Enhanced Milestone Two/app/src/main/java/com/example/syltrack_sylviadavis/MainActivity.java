package com.example.syltrack_sylviadavis;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.syltrack_sylviadavis.data.AppDatabaseHelper;

public class MainActivity extends AppCompatActivity {

    private EditText editUsername, editPassword;
    private Button buttonLogin, buttonCreateAccount;
    private AppDatabaseHelper dbHelper;

    public static final String PREFS_NAME = "SylTrackPrefs";
    public static final String KEY_LOGGED_IN_USER = "loggedInUser";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new AppDatabaseHelper(this);

        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        buttonLogin.setOnClickListener(v -> attemptLogin());

        buttonCreateAccount.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, CreateAccountActivity.class))
        );
    }

    private void attemptLogin() {
        String username = editUsername.getText().toString().trim();
        String password = editPassword.getText().toString().trim();

        // ✅ Stronger validation (security mindset)
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter username and password.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (username.length() < 3) {
            Toast.makeText(this, "Username must be at least 3 characters.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (password.length() < 4) {
            Toast.makeText(this, "Password must be at least 4 characters.", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean valid = dbHelper.validateLogin(username, password);

        if (valid) {
            // ✅ Save who is logged in
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            prefs.edit().putString(KEY_LOGGED_IN_USER, username).apply();

            Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(MainActivity.this, DashboardActivity.class));
            finish();
        } else {
            Toast.makeText(this, "Invalid username or password.", Toast.LENGTH_SHORT).show();
        }
    }
}

package com.example.syltrack_sylviadavis;

/**
 * WeightEntry
 * - Simple model class representing one row in the weights table
 */
public class WeightEntry {

    public long id;
    public String date;
    public double weight;

    public WeightEntry(long id, String date, double weight) {
        this.id = id;
        this.date = date;
        this.weight = weight;
    }
}

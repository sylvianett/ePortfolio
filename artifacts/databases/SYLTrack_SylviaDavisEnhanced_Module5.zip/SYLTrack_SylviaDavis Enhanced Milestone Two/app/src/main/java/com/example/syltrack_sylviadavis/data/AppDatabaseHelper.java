package com.example.syltrack_sylviadavis.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class AppDatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "syltrack.db";

    // ✅ Bump when schema changes
    private static final int DATABASE_VERSION = 5;

    // ===================== USERS TABLE =====================
    public static final String TABLE_USERS = "users";
    public static final String COL_USER_ID = "id";
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD = "password";

    private static final String SQL_CREATE_USERS =
            "CREATE TABLE IF NOT EXISTS " + TABLE_USERS + " (" +
                    COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COL_USERNAME + " TEXT NOT NULL UNIQUE, " +
                    COL_PASSWORD + " TEXT NOT NULL" +
                    ");";

    // ===================== WEIGHTS TABLE =====================
    public static final String TABLE_WEIGHTS = "weights";
    public static final String COL_WEIGHT_ID = "id";
    public static final String COL_WEIGHT_DATE = "date";        // store as YYYY-MM-DD
    public static final String COL_WEIGHT_VALUE = "weight";
    public static final String COL_WEIGHT_GOAL = "goal";
    public static final String COL_WEIGHT_USERNAME = "username";

    // ✅ Enhancement: UNIQUE(username, date) prevents duplicate daily entries per user
    private static final String SQL_CREATE_WEIGHTS =
            "CREATE TABLE IF NOT EXISTS " + TABLE_WEIGHTS + " (" +
                    COL_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COL_WEIGHT_DATE + " TEXT NOT NULL, " +
                    COL_WEIGHT_VALUE + " REAL NOT NULL, " +
                    COL_WEIGHT_GOAL + " INTEGER NOT NULL, " +
                    COL_WEIGHT_USERNAME + " TEXT NOT NULL, " +
                    "UNIQUE(" + COL_WEIGHT_USERNAME + ", " + COL_WEIGHT_DATE + ")" +
                    ");";

    // ✅ Enhancement: index helps query performance for user + date lookups
    private static final String SQL_CREATE_WEIGHTS_INDEX =
            "CREATE INDEX IF NOT EXISTS idx_weights_user_date ON " +
                    TABLE_WEIGHTS + "(" + COL_WEIGHT_USERNAME + ", " + COL_WEIGHT_DATE + ");";

    public AppDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_USERS);
        db.execSQL(SQL_CREATE_WEIGHTS);
        db.execSQL(SQL_CREATE_WEIGHTS_INDEX);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // simple rebuild for class project
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTS);
        onCreate(db);
    }

    // ===================== SMALL VALIDATION HELPERS =====================

    private boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }

    private boolean isValidWeight(double weight) {
        // ✅ guardrails: prevents invalid/corrupt data
        return weight > 0 && weight < 1500;
    }

    // ===================== LOGIN HELPERS =====================

    public boolean userExists(String username) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.query(
                    TABLE_USERS,
                    new String[]{COL_USER_ID},
                    COL_USERNAME + "=?",
                    new String[]{username},
                    null, null, null
            );
            return cursor != null && cursor.moveToFirst();
        } finally {
            if (cursor != null) cursor.close();
            db.close();
        }
    }

    public boolean addUser(String username, String password) {
        if (isBlank(username) || isBlank(password)) return false;

        SQLiteDatabase db = getWritableDatabase();
        try {
            ContentValues values = new ContentValues();
            values.put(COL_USERNAME, username.trim());
            values.put(COL_PASSWORD, password);
            long result = db.insert(TABLE_USERS, null, values);
            return result != -1;
        } finally {
            db.close();
        }
    }

    public boolean validateLogin(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.query(
                    TABLE_USERS,
                    new String[]{COL_USER_ID},
                    COL_USERNAME + "=? AND " + COL_PASSWORD + "=?",
                    new String[]{username, password},
                    null, null, null
            );
            return cursor != null && cursor.moveToFirst();
        } finally {
            if (cursor != null) cursor.close();
            db.close();
        }
    }

    // ===================== WEIGHTS CRUD (PER USER) =====================

    // ✅ Enhancement: explicit duplicate check (UNIQUE constraint is also a backstop)
    public boolean weightEntryExists(String username, String date) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.query(
                    TABLE_WEIGHTS,
                    new String[]{COL_WEIGHT_ID},
                    COL_WEIGHT_USERNAME + "=? AND " + COL_WEIGHT_DATE + "=?",
                    new String[]{username, date},
                    null, null, null
            );
            return cursor != null && cursor.moveToFirst();
        } finally {
            if (cursor != null) cursor.close();
            db.close();
        }
    }

    // ✅ Enhanced addWeight: validates inputs to protect DB integrity
    public long addWeight(String username, String date, double weight, int goal) {

        // Validation
        if (isBlank(username) || isBlank(date) || !isValidWeight(weight) || goal <= 0) {
            return -1; // invalid input
        }

        String safeUsername = username.trim();
        String safeDate = date.trim();

        // Duplicate prevention (same user + same date)
        if (weightEntryExists(safeUsername, safeDate)) {
            return -1;
        }

        SQLiteDatabase db = getWritableDatabase();
        try {
            ContentValues values = new ContentValues();
            values.put(COL_WEIGHT_USERNAME, safeUsername);
            values.put(COL_WEIGHT_DATE, safeDate);
            values.put(COL_WEIGHT_VALUE, weight);
            values.put(COL_WEIGHT_GOAL, goal);
            return db.insert(TABLE_WEIGHTS, null, values);
        } finally {
            db.close();
        }
    }

    // ✅ Enhanced query: ordered newest to oldest for better UX
    public Cursor getAllWeightsForUser(String username) {
        SQLiteDatabase db = getReadableDatabase();
        return db.query(
                TABLE_WEIGHTS,
                null,
                COL_WEIGHT_USERNAME + "=?",
                new String[]{username},
                null,
                null,
                COL_WEIGHT_DATE + " DESC, " + COL_WEIGHT_ID + " DESC"
        );
    }

    public int deleteWeight(long id) {
        SQLiteDatabase db = getWritableDatabase();
        try {
            return db.delete(
                    TABLE_WEIGHTS,
                    COL_WEIGHT_ID + "=?",
                    new String[]{String.valueOf(id)}
            );
        } finally {
            db.close();
        }
    }

    // ===================== SUMMARY / ANALYTICS (Milestone Four) =====================

    // ✅ Enhancement: average weight over last 7 days (demonstrates analytical querying)
    public Double getAverageWeightLast7Days(String username) {
        if (isBlank(username)) return null;

        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = null;
        try {
            // NOTE: Works best if date is stored as YYYY-MM-DD
            String sql =
                    "SELECT AVG(" + COL_WEIGHT_VALUE + ") " +
                            "FROM " + TABLE_WEIGHTS + " " +
                            "WHERE " + COL_WEIGHT_USERNAME + "=? " +
                            "AND date(" + COL_WEIGHT_DATE + ") >= date('now','-7 day');";

            cursor = db.rawQuery(sql, new String[]{username.trim()});

            if (cursor.moveToFirst() && !cursor.isNull(0)) {
                return cursor.getDouble(0);
            }
            return null;
        } finally {
            if (cursor != null) cursor.close();
        }
    }
}
